# Online Exam System

Client Side :-

1. Registration Form for new users.

2. Personalized profile of each student.

3. Subjects according to their respective years.

4. Viewing of results of previous tests.

Admin Side :-

1. Add or remove questions from database.

2. Viewing results of all the registered users.

3. Access to whole user database.